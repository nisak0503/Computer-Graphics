Files provided by Random Talking Bush.
Textured and uploaded by Roxas358.
No credit needed.